![Pack Icon](https://raw.githubusercontent.com/Domi04151309/Autumn/master/pack.png)

# Autumn
Autumn is a resource pack for Minecraft Java Edition that works as an add-on for other resourcepacks.
This add-on recolors the game so that it looks like it is autumn. OptiFine is required.

### Screenshots
![Minecraft Screenshot](https://raw.githubusercontent.com/Domi04151309/Autumn/master/preview.jpg)

### How to Install
You have to download this resource pack and [Faithful x32](https://faithful.team/downloads/) or any other pack.
After you have placed both packs in your resourcepacks folder, select both of them.
It is important that the addon is on top of the default faithful pack!
